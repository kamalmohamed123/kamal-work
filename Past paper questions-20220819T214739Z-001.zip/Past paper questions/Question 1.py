equation = 2 ** 3 ** 2 ** 1 
print(equation)