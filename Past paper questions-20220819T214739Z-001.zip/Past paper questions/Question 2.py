message1 = "Peter's sister's name's \"Anna\""
message2 = 'Peter\'s sister\'s name\'s \"Anna\"'
print(message1)
print(message2)