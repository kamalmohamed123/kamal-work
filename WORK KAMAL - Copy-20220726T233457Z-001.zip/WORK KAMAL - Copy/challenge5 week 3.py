a = 3  
b = 1  
c = 2  
lst = [a, c, b]  
lst.sort()  
print(lst)  