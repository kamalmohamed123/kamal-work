lst = ["D", "F", "A", "Z"]  
lst.sort()  
print(lst) 