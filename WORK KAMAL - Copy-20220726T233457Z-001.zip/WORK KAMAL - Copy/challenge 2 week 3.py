lst = [ ]
del lst
print(lst)