a = "A"  
b = "B"  
c = "C"  
d = " "  
lst = [a, b, c, d]  
lst.reverse()  
print(lst)  