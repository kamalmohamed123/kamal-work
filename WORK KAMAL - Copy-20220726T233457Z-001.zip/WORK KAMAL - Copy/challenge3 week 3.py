lst = [1, [2, 3], 4]
print(lst[1])
print(len(lst))