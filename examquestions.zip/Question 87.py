string = str(1/3)
dummy = ''
for character in strong:
    dummy = character + dummy 
print(dummy[-1])