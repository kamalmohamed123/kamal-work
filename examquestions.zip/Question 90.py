the_list = 'alpha;beta;gamma'.split(":")
the_string = ''.join(the_list)
print(the_string.isaplpha())

#The answer is A