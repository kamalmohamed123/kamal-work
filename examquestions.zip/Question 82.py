#Answer A

try:
    print(0/0)
except:
    print(0/1)
else:
    print(0/2)

#Answer C

import math

try:
    print(math.sqrt(-1))
except:
    print(math.sqrt(0))
else:
    print(math.sqrt(1))