import sys
import math

b1 = type(dir(math)[0]) is str
b2 = type(sys.path[-1]) is str
print(b1 and b2)