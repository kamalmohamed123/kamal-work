import random
random.seed(1)
v1 = random.random()
random.seed(1)
v2 = random.random()
v1>=1
random.choice([1, 2, 3])>=1