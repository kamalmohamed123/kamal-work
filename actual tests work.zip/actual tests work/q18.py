list1= [False for i in range (1,10)]
list2= list1 [-1:1:-1]
print(list2)