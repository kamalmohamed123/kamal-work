a=[1]
b=a
a[0]=0
print(len(a)==len(b))