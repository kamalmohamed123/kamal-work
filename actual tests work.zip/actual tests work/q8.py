for i in range (1,3):
    print("*", end="")
else:
    print("*")