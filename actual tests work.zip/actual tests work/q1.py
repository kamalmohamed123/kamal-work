i=0
while i!=0:
    i=i-1
else:
    i=i+1

print(i)