lst= [x for x in range (5)]
lst= list (filter (lambda x: x % 2==0, lst))
print (len(lst))
