def fun (a,b=0):
    return a*b