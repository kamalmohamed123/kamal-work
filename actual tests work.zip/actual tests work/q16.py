lst=[1,2,3,4]
lst=lst[-3:-2]
lst=lst[-1]
print(lst)