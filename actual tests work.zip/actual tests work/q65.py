def unclear (x):
    if x % 2==1:
        return 0

print )unclear (1)+ unclear (2))