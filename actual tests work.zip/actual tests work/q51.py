dct ={'pi' : 3.14}
dct ['pi'] = 3.1415