s='abc'
for i in len(s):
    s[i]=s[i].upper()
pint(s)