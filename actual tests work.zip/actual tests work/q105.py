mytu=('a', 'b', 'c')
m= tuple(map(lambda x: chr(ord(x) +1), mytu))
print(m[-2])