def fun (a, b):
    return a+b

res= fun (1,2)