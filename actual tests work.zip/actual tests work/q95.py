class Upper:
    def method (self):
        return 'upper'

class Lower(Upper):
    def method(self):
        return 'lower'

Object=Upper()
print(isinstance(Object,Lower), end=' ')
print(Object.method())