def x():  #line 01
    return 2  #line02

x=1+x()
print(x)