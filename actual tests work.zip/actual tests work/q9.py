print(.3423e2)
print(.3423e-2)