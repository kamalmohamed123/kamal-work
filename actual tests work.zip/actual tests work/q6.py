a='ant'
b="bat"
c='camel'
print (a, b, c, sep='"')