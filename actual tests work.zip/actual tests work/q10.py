a=2
if a>0:
    a+=1
else:
        a-=1
print(a)