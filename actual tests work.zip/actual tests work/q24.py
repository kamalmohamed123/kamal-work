def a (l,I):
    return l [I]
print(a(0,[1))