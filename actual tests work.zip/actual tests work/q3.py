for i in range (10):
    pass