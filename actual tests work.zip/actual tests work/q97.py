from xxlimited import foo


class Class:
    __Var = 0
    def foo(self):
        Class._Class__Var +=1
        self.__prop = Class._Class__Var

o1 = Class()
01.foo
o2 = Class()
o2.foo()
print(o2._Class__Var+01._Class__prop)