i=5
while i>0:
    i=i//2
    if i% 2=0:
        break
else:
    i+=1
    print(i)