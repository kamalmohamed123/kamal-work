a=[0]
b=a[:]
a[0]=1
print(a[0]-1==b[0])
print(len(a)==len(b))