from re import I


def f(n):
    for i in range(1,n+1):
        yeild I

print(f(2))