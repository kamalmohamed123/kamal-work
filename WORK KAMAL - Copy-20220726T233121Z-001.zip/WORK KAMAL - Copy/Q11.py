name=input("Enter your name:")
print ("Hello " + name + ", would you like to learn some Python today?")