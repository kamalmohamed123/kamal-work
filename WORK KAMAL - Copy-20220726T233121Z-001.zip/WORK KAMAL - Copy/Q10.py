selfish="1234567"
print(selfish[0:1])