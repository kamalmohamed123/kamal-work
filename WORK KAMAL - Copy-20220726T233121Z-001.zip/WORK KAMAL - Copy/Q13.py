full_name2 = " Eric "
rstrip = ("\t" + full_name2.rstrip())
lstrip = ("\t" + full_name2.lstrip())
strip = ("\t" + full_name2.strip())
print(full_name2)
print("Right Whitespace Stripping:\n\t" + rstrip)
print("Left Whitespace Stripping:\n\t" + lstrip)
print("Whitespace Stripping:\n\t" + strip)
