name=input("Enter your name:")
lname=input("Enter your last name:")
age=input("Enter your age: ")
print("Your first name is: " + name + " \nYour last name is: " + lname + " \nYour age is: " + age)